Hello Sir,

As per the assignment I have made navigation bar. To view the project just click on mainPage.html

I have taken special for the tablet and mobile screens. As per the given instructions everything was made with Vanilla CSS and Vanilla JavaScript. To target mobile and tablet screens I have used Media queries.

I have just used one external file which is the Roboto font file because I think it has a bit better look than the default fonts available.

Sir please have a look and provide me with your valuable feedback.

Regards

Lovenish